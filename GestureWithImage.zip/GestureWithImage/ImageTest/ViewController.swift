//
//  ViewController.swift
//  ImageTest
//
//  Created by Vijay Singh ---------------------on 03/05/18.
//  Copyright © 2018 Mobilecoderz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var currentScale:CGFloat = 0
    var originalScale:CGFloat = 1.0
    var scaleValue:CGFloat = 0
    var radian:CGFloat = 0
    
    @IBOutlet weak var testImageView: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let pan = UIPanGestureRecognizer(target: self, action: #selector(panImage))
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation))

        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinchImage))
        self.testImageView.addGestureRecognizer(pinch)
        self.testImageView.addGestureRecognizer(pan)
        self.testImageView.addGestureRecognizer(pan)
        self.testImageView.addGestureRecognizer(rotate)

        self.testImageView.isUserInteractionEnabled = true

    }

    @IBAction func plusAction(_ sender: Any) {
        originalScale = 1
        
        var cScale = self.testImageView.frame.size.width / self.testImageView.bounds.size.width
        
        let temp :CGFloat = 2
        if (cScale + 0.1) > temp {
            return
        } else {
            cScale = cScale + 0.1
            print("+ plus = \(cScale)")
            originalScale = originalScale + 0.1
            self.testImageView.transform = self.testImageView.transform.scaledBy(x: originalScale, y: originalScale)

        }
       
    }
    
    
    @IBAction func minusAction(_ sender: Any) {
        originalScale = 1

        var cScale = self.testImageView.frame.size.width / self.testImageView.bounds.size.width

        
        let temp :CGFloat = 0.75
        if (cScale - 0.1) < temp {
            return
        } else {
            cScale = cScale - 0.1
            print("- minus = \(cScale)")
            
            originalScale = originalScale - 0.1
            self.testImageView.transform = self.testImageView.transform.scaledBy(x: originalScale, y: originalScale)
        }
        
    }
    
    
    @objc func panImage(_ recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: self.view)
        guard let view = recognizer.view else{return}
        view.center = CGPoint(x: view.center.x + translation.x, y: view.center.y + translation.y)
        recognizer.setTranslation(CGPoint.zero, in: self.view)
    }
    
    @objc func pinchImage(_ recognizer: UIPinchGestureRecognizer) {
        if scaleValue > 2.0 && recognizer.scale > 1.0 { return }
        if scaleValue < 0.75 && recognizer.scale < 1.0 { return }

        guard let view = recognizer.view else{return}
        view.transform = view.transform.scaledBy(x: recognizer.scale, y: recognizer.scale)
        recognizer.scale = 1.0
        scaleValue = self.testImageView.frame.size.width / self.testImageView.bounds.size.width
        print(scaleValue)
    }

    @objc func handleRotation(recognizer:UIRotationGestureRecognizer){
        guard let view = recognizer.view else {return}
        view.transform = view.transform.rotated(by: recognizer.rotation)
        if recognizer.rotation == 0 { return }
        radian = recognizer.rotation
        print("Radian value \(radian)")
        recognizer.rotation = 0
    }
    
   
}

