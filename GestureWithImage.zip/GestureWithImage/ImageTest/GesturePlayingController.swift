//
//  GesturePlayingController.swift
//  GesturePlaying
//
//  Created by Vijay Singh Raghav on 06/10/19.
//  Copyright © 2019 iOS Developer. All rights reserved.
//

import UIKit

class GesturePlayingController: UIViewController {

    var currentScale:CGFloat = 0
    var originalScale:CGFloat = 1.0
    var scaleValue:CGFloat = 0
    var radian:CGFloat = 0
    
    let myImageView: UIImageView = {
        $0.contentMode = .scaleAspectFill
        $0.image = UIImage(named: "testImage")
        $0.isUserInteractionEnabled = true
        return $0
    }(UIImageView())
        
    override func viewDidLoad() {
        super.viewDidLoad()
        addGesture()
    }
    
    func addGesture() {
        let pan = UIPanGestureRecognizer(target: self, action: #selector(panImage))
        let rotate = UIRotationGestureRecognizer(target: self, action: #selector(handleRotation))
        
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(pinchImage))
        myImageView.addGestureRecognizer(pinch)
        myImageView.addGestureRecognizer(pan)
        myImageView.addGestureRecognizer(pan)
        myImageView.addGestureRecognizer(rotate)
    }
    
    @IBAction func plusAction(_ sender: Any) {
        originalScale = 1
        
        var cScale = myImageView.frame.size.width / myImageView.bounds.size.width
        
        let temp :CGFloat = 2
        if (cScale + 0.1) > temp {
            return
        } else {
            cScale = cScale + 0.1
            print("+ plus = \(cScale)")
            originalScale = originalScale + 0.1
            myImageView.transform = myImageView.transform.scaledBy(x: originalScale, y: originalScale)
            
        }
    }
    
    @IBAction func minusAction(_ sender: Any) {
        originalScale = 1
        
        var cScale = myImageView.frame.size.width / myImageView.bounds.size.width
        
        let temp :CGFloat = 0.75
        if (cScale - 0.1) < temp {
            return
        } else {
            cScale = cScale - 0.1
            print("- minus = \(cScale)")
            
            originalScale = originalScale - 0.1
            myImageView.transform = myImageView.transform.scaledBy(x: originalScale, y: originalScale)
        }
        
    }
    
    @objc func panImage(_ recognizer: UIPanGestureRecognizer) {
        let translation = recognizer.translation(in: view)
        guard let view = recognizer.view else { return }
        view.center = CGPoint(x: view.center.x + translation.x, y: view.center.y + translation.y)
        recognizer.setTranslation(CGPoint.zero, in: view)
    }
    
    @objc func pinchImage(_ recognizer: UIPinchGestureRecognizer) {
        if scaleValue > 2.0 && recognizer.scale > 1.0 { return }
        if scaleValue < 0.75 && recognizer.scale < 1.0 { return }
        
        guard let view = recognizer.view else{return}
        view.transform = view.transform.scaledBy(x: recognizer.scale, y: recognizer.scale)
        recognizer.scale = 1.0
        scaleValue = myImageView.frame.size.width / myImageView.bounds.size.width
        print(scaleValue)
    }
    
    @objc func handleRotation(recognizer:UIRotationGestureRecognizer){
        guard let view = recognizer.view else {return}
        view.transform = view.transform.rotated(by: recognizer.rotation)
        if recognizer.rotation == 0 { return }
        radian = recognizer.rotation
        print("Radian value \(radian)")
        recognizer.rotation = 0
    }
}

